/*
 * PONG CLONE v0.3
 * CMP211
 * Coded by Trinh D.D. Nguyen, 2018
 * 
 * COMPILE:
 * 	MinGW: gcc -s pong.c -o pong -lmingw32 -lSDL2main -lSDL2 -mwindows
 *   MSVC: cl pong.c
 * 	maCOS: gcc pong.c -o pong -framework SDL2
 *  Linux: gcc pong.c -o pong -lSDL2
 * 
 * TODO:
 * . Implement Player vs Computer mode
 * . Improve collision detection
 */
#include <SDL2/SDL.h>

#ifdef _MSC_VER					/* for linking using CL or MSVC */
#	pragma comment (lib,    "sdl2main.lib")
#	pragma comment (lib,    "sdl2.lib")
#	pragma comment (linker, "/entry:\"mainCRTStartup\"" ) 
#	pragma comment (linker, "/subsystem:WINDOWS")
#endif

/*-------------------------------------- GLOBAL STUFFS --------------------------------------*/
#ifndef bool					/* C doesnt provide bool type */
#	define bool			int		/* so we have to define it */
#	define false		(0)
#	define true			(1)
#endif

#define	GAME_CELL		(16)						/* a cell size */
#define GAME_BORDER		(GAME_CELL)					/* border width */
#define GAME_WIDTH		(GAME_CELL * 48)			/* game screen width */
#define GAME_HEIGHT		(GAME_CELL * 29)			/* game screen height */
#define GAME_TOP		GAME_BORDER					/* collision top */
#define GAME_BOTTOM		(GAME_HEIGHT-GAME_BORDER)	/* collision bottom */
#define	GAME_MAXSCORE	100							/* maximum score */

#define CR_WHITE		0xFF				/* color white */
#define CR_GRAY			0x66				/* color gray */
#define CR_BLACK		0x00				/* color black */

#define DIGIT_WIDTH		3					/* digit width */
#define DIGIT_HEIGHT	5					/* digit height */
char DIGITS[10*DIGIT_HEIGHT] =				/* digits font */ 
{
	0x07, 0x05, 0x05, 0x05, 0x07,	/* 0 */
	0x06, 0x02, 0x02, 0x02, 0x07,	/* 1 */
	0x07, 0x01, 0x07, 0x04, 0x07,	/* 2 */
	0x07, 0x01, 0x03, 0x01, 0x07,	/* 3 */
	0x05, 0x05, 0x07, 0x01, 0x01,	/* 4 */
	0x07, 0x04, 0x07, 0x01, 0x07,	/* 5 */
	0x07, 0x04, 0x07, 0x05, 0x07,	/* 6 */
	0x07, 0x01, 0x01, 0x01, 0x01,	/* 7 */
	0x07, 0x05, 0x07, 0x05, 0x07,	/* 8 */
	0x07, 0x05, 0x07, 0x01, 0x01	/* 9 */
};

SDL_Window * g_window = NULL;			/* SDL window pointer */
SDL_Renderer * g_renderer = NULL;		/* SDL renderer pointer */

void drawRect(int x, int y, int w, int h, int intensity)
{
	SDL_Rect rc = {x, y, w, h};
	SDL_SetRenderDrawColor(g_renderer, intensity, intensity, intensity, 0xFF);
	SDL_RenderFillRect(g_renderer, &rc);
}

void drawDigit(int x, int y, int digit)	/* draw a digit */
{
	for (int i = 0; i < DIGIT_HEIGHT; i++)
	{
		char value = DIGITS[digit*DIGIT_HEIGHT+i];
		for (int j = 0; j < DIGIT_WIDTH; j++)
		{
			if (value & 0x4)	/* test the 1st bit */
				drawRect(x+j*GAME_CELL, y+i*GAME_CELL, 
						 GAME_CELL, GAME_CELL, CR_GRAY);
			value <<= 1;		/* then, throw it away */
		}
	}
}

void drawNumber(int x, int y, short digit)
{
	char tmp[2] = {0, 0};
	tmp[0] = (digit/10)%10+'0';
	tmp[1] = (digit%10)   +'0';
	for (int i = 0, xx = x; 
		 i < 2; 
		 i++, xx+=DIGIT_WIDTH*GAME_CELL+GAME_CELL)
		drawDigit(xx, y, tmp[i]-'0');
}

/*-------------------------------------- BALL HANDLERS --------------------------------------*/
#define BALL_SIZE			GAME_CELL
#define BALL_SPEED			GAME_CELL/4		/* speed = 1/4 cell size */
#define BALL_COLLIDE_LEFT	(BALL_SIZE)
#define BALL_COLLIDE_RIGHT	(GAME_WIDTH-BALL_SIZE)
#define BALL_COLLIDE_TOP	(GAME_TOP)
#define BALL_COLLIDE_BOTTOM	(GAME_BOTTOM-BALL_SIZE)
#define BALL_START_X		(GAME_WIDTH-BALL_SIZE) >> 1
#define BALL_START_Y		(GAME_HEIGHT-BALL_SIZE) >> 2

typedef struct ball
{
	int x, y;		/* coordinates */
	int vx, vy;		/* movement vector */
} BALL;

void ballInit(BALL * ball, int x, int y)
{
	ball->x = x;
	ball->y = y;
	ball->vx = ball->vy = -1;
}

void ballDraw(BALL * ball)
{
	drawRect(ball->x, ball->y, BALL_SIZE, BALL_SIZE, CR_WHITE);
}

void ballUpdate(BALL * ball)
{
	ball->x += BALL_SPEED * ball->vx;
	ball->y += BALL_SPEED * ball->vy;
}

/*-------------------------------------- RACKET HANDLERS --------------------------------------*/
#define RACKET_WIDTH			GAME_CELL
#define RACKET_HEIGHT			GAME_CELL*5
#define RACKET_SPEED			16
#define RACKET_GAP				GAME_CELL*2
#define RACKET_LEFT				(RACKET_GAP)
#define RACKET_RIGHT			(GAME_WIDTH-RACKET_WIDTH-RACKET_GAP)
#define RACKET_COLLIDE_TOP		(GAME_TOP)
#define RACKET_COLLIDE_BOTTOM	(GAME_BOTTOM-RACKET_HEIGHT)
#define RACKET_MOVE_UP			false
#define RACKET_MOVE_DOWN		true

typedef struct racket
{
	int x, y;
	int score;
} RACKET;

void racketInit(RACKET * pad, int x, int y)
{
	pad->x = x;
	pad->y = y;
	pad->score = 0;
}

void racketDraw(RACKET * pad)
{
	drawRect(pad->x, pad->y, RACKET_WIDTH, RACKET_HEIGHT, CR_WHITE);
}

void racketUpdate(RACKET * pad, bool dir)
{
	if (dir == RACKET_MOVE_UP)		/* going up */
	{
		if (pad->y - RACKET_SPEED > RACKET_COLLIDE_TOP)
			pad->y -= RACKET_SPEED;
		else
			pad->y = RACKET_COLLIDE_TOP;
	}
	else							/* going down */
	{
		if (pad->y + RACKET_SPEED < RACKET_COLLIDE_BOTTOM)
			pad->y += RACKET_SPEED;
		else
			pad->y = RACKET_COLLIDE_BOTTOM;
	}
}

/*-------------------------------------- GAME HANDLERS ---------------------------------------*/
typedef struct game
{
	BALL    ball;
	RACKET  player1;
	RACKET  player2;
	bool    running;
} GAME;

bool gameInit(GAME * game, bool fullscreen)
{
	SDL_Init(SDL_INIT_VIDEO);
	g_window = SDL_CreateWindow("Pong Game", 
								SDL_WINDOWPOS_CENTERED, 
								SDL_WINDOWPOS_CENTERED,
								GAME_WIDTH, GAME_HEIGHT,
								SDL_WINDOW_SHOWN | 
								(fullscreen ? SDL_WINDOW_FULLSCREEN : 0));
	if(!g_window)
		return false;

	g_renderer = SDL_CreateRenderer(g_window, -1, 
									SDL_RENDERER_ACCELERATED | 
									SDL_RENDERER_PRESENTVSYNC);
	if (!g_renderer)
		return false;

	SDL_RenderClear(g_renderer);

	ballInit(&game->ball, BALL_START_X, BALL_START_Y);
	racketInit(&game->player1, RACKET_LEFT, (GAME_HEIGHT-RACKET_HEIGHT)>>1);
	racketInit(&game->player2, RACKET_RIGHT, (GAME_HEIGHT-RACKET_HEIGHT)>>1);

	game->running = false;
	return true;
}

void gameShutdown(GAME * game)
{
	SDL_DestroyRenderer(g_renderer);
	SDL_DestroyWindow(g_window);
	SDL_Quit();
}

void gameDraw(GAME * game)
{
	/* clear the screen */
	SDL_SetRenderDrawColor(g_renderer, 0, 0, 0, SDL_ALPHA_OPAQUE);
	SDL_RenderClear(g_renderer);

	/* draw game board */
	drawRect(0, 0, GAME_WIDTH, GAME_BORDER, CR_GRAY);
	drawRect(0, GAME_BOTTOM, GAME_WIDTH, GAME_BORDER, CR_GRAY);
	int cells = (GAME_HEIGHT / GAME_BORDER);
	for (int i = 0; i < cells; i+=2)
		drawRect((GAME_WIDTH-GAME_BORDER)>>1, (i+1)*GAME_BORDER, 
				 GAME_BORDER, GAME_BORDER, CR_GRAY);

	/* draw scores */
	drawNumber((GAME_WIDTH>>1)-GAME_CELL*3-DIGIT_WIDTH*GAME_CELL*2, GAME_TOP*2, game->player1.score);
	drawNumber((GAME_WIDTH>>1)+GAME_CELL*2, GAME_TOP*2, game->player2.score);

	ballDraw(&game->ball);              /* draw the ball */
	racketDraw(&game->player1);         /* draw player 1's racket */
	racketDraw(&game->player2);         /* draw player 2's racket */

	SDL_RenderPresent(g_renderer);      /* flip the buffer */
}

bool gameCheckCollide(GAME * game)
{
	/* ball collide with player 1? */
	bool p1 = (game->ball.y >= game->player1.y) && 
			  (game->ball.y <  game->player1.y + RACKET_HEIGHT) &&
			  (game->ball.x <=  game->player1.x + RACKET_WIDTH);

	/* ball collide with player 2? */
	bool p2 = (game->ball.y >= game->player2.y) && 
			  (game->ball.y <  game->player2.y + RACKET_HEIGHT) &&
			  (game->ball.x+BALL_SIZE >=  game->player2.x);
	return p1 | p2;
}

void gameGoal(GAME * game, RACKET * racket)
{
	racket->score++;
	game->ball.x = BALL_START_X;
	game->ball.y = BALL_START_Y;  
}

void gameUpdate(GAME * game)
{
	ballUpdate(&game->ball);		/* update game states */

	/* ball collides with top or bottom walls */
	if (game->ball.y < GAME_TOP || game->ball.y > BALL_COLLIDE_BOTTOM)
		game->ball.vy = -game->ball.vy;

	if (gameCheckCollide(game))		/* ball collides with players */
		game->ball.vx = -game->ball.vx;

	/* goal scored, check for player that scores */
	if (game->ball.x < game->player1.x) gameGoal(game, &game->player2);
	if (game->ball.x > game->player2.x+RACKET_WIDTH) gameGoal(game, &game->player1);

	/* stop the game if any of the player's score reach 10 */
	if (game->player1.score == GAME_MAXSCORE || 
		game->player2.score == GAME_MAXSCORE)
		game->running = false;
}

void gameInput(GAME * game)
{
	SDL_Event e;
	if (SDL_PollEvent(&e)) {
		switch (e.type) {
		case SDL_KEYDOWN:
			switch (e.key.keysym.sym) 
			{
			case SDLK_w: 
				racketUpdate(&game->player1, RACKET_MOVE_UP);
				break;
			case SDLK_s: 
				racketUpdate(&game->player1, RACKET_MOVE_DOWN);
				break;
			case SDLK_UP: 
				racketUpdate(&game->player2, RACKET_MOVE_UP);
				break;
			case SDLK_DOWN: 
				racketUpdate(&game->player2, RACKET_MOVE_DOWN);
				break;
			case SDLK_ESCAPE: 
				game->running = false;
				break;
			}
			break;
		case SDL_QUIT:
			game->running = false;
			break;
		}
	}
}

void gameLoop(GAME * game)
{
	game->running = true;
	while (game->running) 
	{
		gameInput(game);
		gameUpdate(game);
		gameDraw(game);
	}
}

/*---------------------------------------- MAIN GAME -----------------------------------------*/
int main(int argc, char ** argv)
{
	GAME game;
	if (!gameInit(&game, false)) return -1;
	gameLoop(&game);
	gameShutdown(&game);
	return 0;
}