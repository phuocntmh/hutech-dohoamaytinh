//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WINDOW_WIDTH    640
#define WINDOW_HEIGHT   480

void draw();
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)
{
    glutInit(argc, argv);                               // GLUT initializer
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);    // Specify OpenGL window's size
    glutInitDisplayMode(GLUT_RGBA);  				    // Specify display mode
    glutCreateWindow(argv[0]);                          // Create OpenGL window
    glutDisplayFunc(draw);                              // Callback for drawer
    glutKeyboardFunc(keyboard);                         // Callback for keyboard handler

    // Scene setup
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
}

void run()
{
    glutMainLoop();
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:    exit(0);                                    // ESC = quit
        default:    break;
    }
}

#define W 640
#define H 480

void draw()
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);

    // draw a white triangle, replace it with your drawing here
    glBegin(GL_TRIANGLES);
        glVertex2i(W/2, H/4);
        glVertex2i(3*W/4, 3*H/4);
        glVertex2i(W/4, 3*H/4);
    glEnd();

    glutSwapBuffers();
}

int main(int argc, char ** argv)
{
    init(&argc, argv);
    run();
    return 0;
}