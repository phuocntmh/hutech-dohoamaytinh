//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>
#ifndef _MSC_VER
#	include <unistd.h>
#endif
#include <math.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WINDOW_WIDTH    640
#define WINDOW_HEIGHT   480
#define CIRCLE_STEPS    40                              // number of steps to draw circle
#define MAX_STARS       300
#define FLY_SPEED       10
#ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif

void glCircle(GLint x, GLint y, GLint radius) 
{
	GLfloat twicePi = (GLfloat) 2.0f * M_PI;
	glBegin(GL_TRIANGLE_FAN);
        	glVertex2i(x, y);				            // circle center
        	for(int i = 0; i <= CIRCLE_STEPS; i++)		// draw a triangle fan
        	{
                GLfloat angle = i * twicePi / CIRCLE_STEPS;
            	glVertex2i( (GLint) (x + (radius * cos(angle))+0.5), 
                	        (GLint) (y + (radius * sin(angle))+0.5));
        	}
    	glEnd();
}

typedef struct star
{
    int     x, y;
    int     radius;
    int     velocity;
    float   color;
} STAR;

STAR    sky[MAX_STARS];

void skyInit()
{
    for (int i = 0; i < MAX_STARS; i++)
    {
        sky[i].x = rand() % WINDOW_WIDTH;
        sky[i].y = rand() % WINDOW_HEIGHT;
        sky[i].radius = 1 + rand() % 3;
        sky[i].color = sky[i].radius/3.0f;
	    sky[i].velocity = sky[i].radius*2 + rand() % 3;
    }
}

void skyDraw()
{
    for(int i = 0; i < MAX_STARS; i++)
    {
        glColor3f(sky[i].color, sky[i].color, sky[i].color);
        glCircle(sky[i].x, sky[i].y, sky[i].radius);
    }
}

void skyAnimate()                          // put your drawing code here
{        
    for(int i = 0; i < MAX_STARS; i++)
    {
        sky[i].x -= sky[i].velocity;
        if (sky[i].x < 0)
        {
            sky[i].x = WINDOW_WIDTH-1;
            sky[i].y = rand() % WINDOW_HEIGHT;
            sky[i].radius = 1 + rand() % 3;
            sky[i].color = sky[i].radius/3.0f;
	        sky[i].velocity = sky[i].radius * 2 + rand() % 3;
        }
    }
}

void draw();
void idle();
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)
{
    glutInit(argc, argv);                                       // GLUT initializer
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);            // Specify OpenGL window's size
    glutInitDisplayMode(GLUT_RGBA);                             // Specify display mode
    glutCreateWindow(argv[0]);                                  // Create OpenGL window
    glutDisplayFunc(draw);                                      // Callback for renderer
    glutIdleFunc(idle);                                         // Callback for idle state
    glutKeyboardFunc(keyboard);                                 // Callback for keyboard handler

    // Scene setup
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

    skyInit();
}

void run()
{
    glutMainLoop();
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:    exit(0);                        // ESC = quit
        default:    break;
    }
}

void draw()
{
	glClear(GL_COLOR_BUFFER_BIT);
	skyDraw();
	glutSwapBuffers();
#ifdef WIN32
	Sleep(FLY_SPEED);
#else
	usleep(FLY_SPEED);
#endif
}

void idle()
{
	skyAnimate();                                   // animate the sky
    glutPostRedisplay();                            // post a redraw message
}

int main(int argc, char ** argv)
{
	init(&argc, argv);
	run();
	return 0;
}