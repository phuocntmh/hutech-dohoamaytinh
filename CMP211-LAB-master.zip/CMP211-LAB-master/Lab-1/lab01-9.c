//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>
#ifndef _MSC_VER
#	include <unistd.h>
#endif
#include <math.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WND_WIDTH       640
#define WND_HEIGHT      480
#define CIRCLE_STEPS    40              // number of steps to draw circle
#define BALL_SPEED      10              // animation speed
#define BALL_SIZE       20              // size of the ball
#ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif

void glCircle(GLint x, GLint y, GLint radius)   // draw a circle
{
	GLfloat twicePi = (GLfloat) 2.0f * M_PI;
	glBegin(GL_TRIANGLE_FAN);
        	glVertex2i(x, y);				            // circle center
        	for(int i = 0; i <= CIRCLE_STEPS; i++)		// draw a triangle fan
        	{
                GLfloat angle = i * twicePi / CIRCLE_STEPS;
            	glVertex2i( (GLint) (x + (radius * cos(angle))+0.5), 
                	        (GLint) (y + (radius * sin(angle))+0.5));
        	}
    	glEnd();
}

typedef struct ball                     // structure of a ball
{
    int x, y;                           // position
    int radius;                         // radius
    int vx, vy;                         // movement vector for x and y axis
} BALL_TYPE;

BALL_TYPE ball;                         // our ball

void ballInit()                         // init the ball
{
    ball.x = WND_WIDTH/2;               // place it at the center
    ball.y = WND_HEIGHT/2;              // of the window
    ball.radius = BALL_SIZE;            // size of the ball
    ball.vx = 5 * (rand() % 3 - 1);     // randomize initial movement vectors
    ball.vy = 5 * (rand() % 3 - 1);
}

void ballDraw()                         // draw the ball
{
    glCircle(ball.x, ball.y, ball.radius);
}

void ballAnimate()                      // animate the ball
{
    ball.x += ball.vx;                  // move the ball
    ball.y += ball.vy;                  // using the movement vectors
    if (ball.x < ball.radius ||         // left, right edge collision check
        ball.x >= WND_WIDTH-ball.radius)
        ball.vx = -ball.vx;             // bounce back
    if (ball.y < ball.radius ||         // top, bottom edge collision check
        ball.y >= WND_HEIGHT-ball.radius)
        ball.vy = -ball.vy;             // bounce back
}

void draw();
void idle();
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)             // APP INITIALIZER
{
    glutInit(argc, argv);                       // GLUT initializer
    glutInitWindowSize(WND_WIDTH, WND_HEIGHT);  // OpenGL window's size
    glutInitDisplayMode(GLUT_RGBA);             // Specify display mode
    glutCreateWindow(argv[0]);                  // Create OpenGL window
    glutDisplayFunc(draw);                      // Callback for renderer
    glutKeyboardFunc(keyboard);                 // Callback for keyboard handler
    glutIdleFunc(idle);                         // Callback for idle handler

    // Scene setup
    glMatrixMode(GL_PROJECTION);                // view matrix
    glLoadIdentity();
    gluOrtho2D(0, WND_WIDTH, WND_HEIGHT, 0);    // 2D ortho projection
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    ballInit();                                 // init our ball
}

void run()                                      // APP EXECUTOR
{
    glutMainLoop();
}

void keyboard(unsigned char key, int x, int y)  // APP KEYBOARD HANDLER
{
    switch(key)
    {
        case 27:    exit(0);                    // ESC = quit
        default:    break;
    }
}

void draw()                                     // APP SCENE RENDERER
{
	glClear(GL_COLOR_BUFFER_BIT);
	ballDraw();                                 // draw the ball
	glutSwapBuffers();                          // update the window
#ifdef WIN32
	Sleep(BALL_SPEED);
#else
	usleep(BALL_SPEED);
#endif
}

void idle()                                     // APP IDLE HANDLER
{
    ballAnimate();                              // animate the ball
    glutPostRedisplay();                        // request a redraw
}

int main(int argc, char ** argv)
{
	init(&argc, argv);
	run();
	return 0;
}