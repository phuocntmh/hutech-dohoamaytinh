//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WINDOW_WIDTH    640
#define WINDOW_HEIGHT   480

void draw();
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)
{
    glutInit(argc, argv);                               // GLUT initializer
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);    // Specify OpenGL window's size
    glutInitDisplayMode(GLUT_RGBA);                     // Specify display mode
    glutCreateWindow(argv[0]);                          // Create OpenGL window
    glutDisplayFunc(draw);                              // Callback for renderer
    glutKeyboardFunc(keyboard);                         // Callback for keyboard handler

    // Scene setup
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
}

void run()
{
    glutMainLoop();
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:    exit(0);                                    // ESC = quit
        default:    break;
    }
}

// draw a square at (x, y) having the size of edges is 'a'
void glSquare(GLint x, GLint y, GLint a) 
{
    glBegin(GL_POLYGON);
        glVertex2i(x, y);
        glVertex2i(x + a, y);
        glVertex2i(x + a, y + a);
        glVertex2i(x, y + a);
    glEnd();
}

void draw()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);

    GLint size = 200;			            // edge size at 200 pixels
    GLint x = (WINDOW_WIDTH-size)/2;		// horizontal center
    GLint y = (WINDOW_HEIGHT-size)/2;	    // vertical center
    glSquare(x, y, size);

    glutSwapBuffers();
}

int main(int argc, char ** argv)
{
    init(&argc, argv);
    run();
    return 0;
}