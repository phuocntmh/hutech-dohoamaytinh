//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>
#include <math.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WINDOW_WIDTH    640
#define WINDOW_HEIGHT   480
#ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif

void draw();
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)
{
    glutInit(argc, argv);                               // GLUT initializer
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);    // Specify OpenGL window's size
    glutInitDisplayMode(GLUT_RGBA);                     // Specify display mode
    glutCreateWindow(argv[0]);                          // Create OpenGL window
    glutDisplayFunc(draw);                              // Callback for renderer
    glutKeyboardFunc(keyboard);                         // Callback for keyboard handler

    // Scene setup
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
}

void run()
{
    glutMainLoop();
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:    exit(0);                                    // ESC = quit
        default:    break;
    }
}

#define STEPS 40                                                // number of steps to draw

void glCircle(GLint x, GLint y, GLint radius) 
{
	GLfloat twicePi = (GLfloat) 2.0f * M_PI;
	glBegin(GL_TRIANGLE_FAN);
        	glVertex2i(x, y);				            // circle center
        	for(int i = 0; i <= STEPS; i++)		// draw a triangle fan
        	{
                GLfloat angle = i * twicePi / STEPS;
            	glVertex2i( (GLint) (x + (radius * cos(angle))+0.5), 
                	        (GLint) (y + (radius * sin(angle))+0.5));
        	}
    	glEnd();
}

void draw()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glCircle(320, 240, 150);
    glutSwapBuffers();
}

int main(int argc, char ** argv)
{
    init(&argc, argv);
    run();
    return 0;
}