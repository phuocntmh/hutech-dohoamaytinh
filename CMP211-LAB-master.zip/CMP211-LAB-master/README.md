# CMP211-LAB

Danh mục các bài thực tập môn Đồ Họa Máy Tính. Đang được bổ sung và chỉnh sửa.

## Yêu cầu

- Trình biên dịch: MinGW32 hoặc GNU C/C++.
- Hệ điều hành: Windows hoặc macOS. Linux đang trong quá trình hỗ trợ.
- Thư viện: FreeGLUT (Lab 1, 2); SDL2 (Lab 3); GLEW (Lab 5)

## Biên dịch

Tại từng folder của mỗi bài lab, gõ lệnh 'mingw32-make' (đối với MinGW32) hoặc 'make' (đối với GNU C/C++) để biên dịch.

## Giấy phép sử dụng

Các bạn có thể sử dụng các mã nguồn này vào bất kỳ mục đích gì, kể cả thương mại. Nếu có thể vui lòng trích dẫn nguồn đến git này. Vì các mã nguồn này được cung cấp miễn phí, do đó tôi không chịu trách nhiệm về các sự mất mát dữ liệu hoặc hỏng hóc do các đoạn mã này gây ra cho máy tính của bạn. 

USE IT AT YOUR OWN RISK.

## QA

**Q:** Phiên bản OpenGL cần thiết để thực hiện các bài lab này là bao nhiêu?

**A:** Do chỉ thực hiện các nội dung cơ bản về đồ họa máy tính nên các bài lab chỉ đòi hỏi OpenGL tối đa là 2.0.

**Q:** Tôi sử dụng Visual Studio 2015, vậy làm sao tôi có thể biên dịch được các mã nguồn này?

**A:** Mã nguồn của các bài lab này đều được cố gắng hoàn chỉnh sao cho có thể biên dịch được trên tất cả các trình biên dịch C. Visual Studio 2015 cũng hỗ trợ C vì vậy bạn có thể biên dịch được các mã nguồn này, chỉ việc tạo một project và import mã nguồn của bài lab cần biên dịch. Bổ sung thêm #include "stdafx.h" vào đầu tập mã nguồn này là xong.

**Q:** Liệu cấu hình máy tính của tôi có thể chạy được các bài lab này hay không?

**A:** Các bài lab này được thiết kế để vận hành với phiên bản OpenGL tối đa là 2.0. Nếu GPU trên máy tính của bạn có hỗ trợ OpenGL 2.0 thì các bài lab này sẽ hoạt động được, mặc dù tôi không chắc chắn lắm vì tôi chưa có thời gian để thử nghiệm các bài lab này trên nhiều phần cứng khác nhau.

**Q:** Tôi có cần sử dụng thêm các thư viện bổ sung để biên dịch hay không?

**A:** Các thư viện cần thiết cho việc biên dịch đã được liệt kê ở mục **Yêu Cầu**, đó là FreeGLUT, GLEW và SDL 2.0.

**Q:** Khi nào thì Linux được hỗ trợ?

**A:** Tất cả mã nguồn đều được cố gắng tránh sử dụng các thư viện phụ thuộc hệ điều hành, điều này có nghĩa là chúng có thể biên dịch tốt trên các trình biên dịch C. Tuy nhiên, tôi không đủ thời gian để thử nghiệm các mã nguồn này trên Linux, hơn nữa chúng chỉ là các bài tập. Vì vậy nếu các bạn có thể bổ sung, thử nghiệm chúng trên Linux, xin vui lòng cho tôi biết. Rất cảm ơn.