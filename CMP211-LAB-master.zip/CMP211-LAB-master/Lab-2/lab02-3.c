//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WND_WIDTH    640
#define WND_HEIGHT   480

// prototypes: we need a renderer, a keyboard, resizer and idle handlers
void draw();
void idle();
void resize(int width, int height);
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)								// INITIALIZER
{
    glutInit(argc, argv);                                       // FreeGLUT initializer
    glutInitWindowSize(WND_WIDTH, WND_HEIGHT);            // OpenGL window's size
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);   // Display mode
    glutCreateWindow(argv[0]);                                  // create OpenGL window
    glutDisplayFunc(draw);                                      // callback for renderer
    glutKeyboardFunc(keyboard);                                 // callback for keyboard handler
    glutIdleFunc(idle);											// callback for idle handler
    glutReshapeFunc(resize);									// callback for window resizer

    // Scene setup
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);						// set clear color
    glEnable(GL_DEPTH_TEST);									// enable Z-buffer
	glShadeModel(GL_SMOOTH);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

void run()
{
    glutMainLoop();												// program loop
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:    exit(0);                        			// ESC = quit
        default:    break;
    }
}

void resize(int width, int height)								// WINDOW RESIZER
{
    if (!height)												// avoid division by zero
        return;

    glMatrixMode(GL_PROJECTION);								// View matrix
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat) width/height, 1, 15);		// enable perspective projection
    glViewport(0, 0, width, height);							// update the viewport
}

void idle()														// IDLE HANDLER
{
    glutPostRedisplay();										// request a window redraw
}

float angle = 0.0f;												// rotating angle

void draw()														// SCENE RENDERER
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);			// clear the buffers
    glMatrixMode(GL_MODELVIEW);									// Object matrix
    glLoadIdentity();
    glTranslatef(0, 0, -5);										// move the object back
    glRotatef(angle, 0.0, 1.0, 0.0);							// rotate on all 3 axises
    glutSolidTeapot(1.0f);                                      // draw the teapot
    angle += 0.1f;												// update the angle
	glutSwapBuffers();
}

int main(int argc, char ** argv)
{
	init(&argc, argv);
	run();
	return 0;
}
