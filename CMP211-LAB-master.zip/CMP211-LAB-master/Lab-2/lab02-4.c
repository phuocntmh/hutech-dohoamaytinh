//#include "stdafx.h"  // for using with Visual Studio
#include <GL/glut.h>

// for Microsoft Visual Studio only
#ifdef _MSC_VER
#	pragma comment(lib, "opengl32.lib")
#	pragma comment(lib, "glu32.lib")
#	pragma comment(lib, "freeglut.lib")
#endif // _MSC_VER

#define WINDOW_WIDTH    640
#define WINDOW_HEIGHT   480

GLfloat xRot = 0.0f;
GLfloat yRot = 0.0f;
GLfloat zRot = 0.0f;
GLfloat wire = GL_FALSE;

// prototypes: we need a renderer, a keyboard, resizer and idle handlers
void draw();
void idle();
void resize(int width, int height);
void keyboard(unsigned char key, int x, int y);

void init(int * argc, char ** argv)								// INITIALIZER
{
    glutInit(argc, argv);                                       // FreeGLUT initializer
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);            // OpenGL window's size
    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH);   // Display mode
    glutCreateWindow(argv[0]);                                  // create OpenGL window
    glutDisplayFunc(draw);                                      // callback for renderer
    glutKeyboardFunc(keyboard);                                 // callback for keyboard handler
    glutIdleFunc(idle);											// callback for idle handler
    glutReshapeFunc(resize);									// callback for window resizer

    // Scene setup
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);						// set clear color
    glEnable(GL_DEPTH_TEST);									// enable Z-buffer
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

void run()
{
    glutMainLoop();												// program loop
}

void keyboard(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:    exit(0);                        			// ESC = quit
        case 'X':   xRot += 1; break;   
        case 'Y':   yRot += 1; break;
        case 'Z':   zRot += 1; break;
        case 'x':   xRot -= 1; break;   
        case 'y':   yRot -= 1; break;
        case 'z':   zRot -= 1; break;
        case 'w':
        case 'W':   wire = !wire;
                    if (wire)
                    {
                        glDisable(GL_LIGHTING);
                        glDisable(GL_LIGHT0);
                    }
                    else
                    {
                        glEnable(GL_LIGHTING);
                        glEnable(GL_LIGHT0);
                    }
                    break;
        default:    break;
    }
}

void resize(int width, int height)								// WINDOW RESIZER
{
    if (!height)												// avoid division by zero
        return;

    glMatrixMode(GL_PROJECTION);								// View matrix
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat) width/height, 1, 15);		// enable perspective projection
    glViewport(0, 0, width, height);							// update the viewport
}

void idle()														// IDLE HANDLER
{
    glutPostRedisplay();										// request a window redraw
}

float angle = 0.0f;												// rotating angle

void draw()														// SCENE RENDERER
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);			// clear the buffers

    glPushMatrix();
    glMatrixMode(GL_MODELVIEW);									// Object matrix
    glLoadIdentity();

    glTranslatef(0, 0, -5);										// move the object back
    glRotatef(xRot, 1.0f, 0.0f, 0.0f);							// rotate on all 3 axises
    glRotatef(yRot, 0.0f, 1.0f, 0.0f);							// rotate on all 3 axises
    glRotatef(zRot, 0.0f, 0.0f, 1.0f);							// rotate on all 3 axises

    if (wire)
        glutWireTorus(0.5, 1.0, 16, 32);
    else
        glutSolidTorus(0.5, 1.0, 16, 32);

    glPopMatrix;
    angle += 0.1f;												// update the angle
	glutSwapBuffers();
}

int main(int argc, char ** argv)
{
	init(&argc, argv);
	run();
	return 0;
}
